#!/bin/bash

rm -rf ./.vuepress/public/rpc
rm -rf ./spec