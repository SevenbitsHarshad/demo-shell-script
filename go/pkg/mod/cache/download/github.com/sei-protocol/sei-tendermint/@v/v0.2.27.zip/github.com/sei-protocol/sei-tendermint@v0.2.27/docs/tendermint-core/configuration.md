---
order: false
---

# Configuration

This file has moved to the [nodes section](../nodes/configuration.md).
