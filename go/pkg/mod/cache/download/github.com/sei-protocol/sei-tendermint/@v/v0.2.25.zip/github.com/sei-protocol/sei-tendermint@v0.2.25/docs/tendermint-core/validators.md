---
order: false
---

# Validators

This file has moved to the [node section](../nodes/validators.md).
