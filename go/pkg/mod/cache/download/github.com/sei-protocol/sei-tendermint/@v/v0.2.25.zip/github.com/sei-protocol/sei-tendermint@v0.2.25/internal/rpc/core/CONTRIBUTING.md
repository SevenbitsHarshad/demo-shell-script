# Openapi docs

Do not forget to update ../openapi/openapi.yaml if making changes to any
endpoint.
