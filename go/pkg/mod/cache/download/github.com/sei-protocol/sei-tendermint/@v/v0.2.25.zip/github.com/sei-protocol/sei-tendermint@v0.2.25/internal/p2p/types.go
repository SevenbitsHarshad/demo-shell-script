package p2p

import (
	"github.com/tendermint/tendermint/internal/p2p/conn"
)

type ChannelDescriptor = conn.ChannelDescriptor
type ChannelID = conn.ChannelID
