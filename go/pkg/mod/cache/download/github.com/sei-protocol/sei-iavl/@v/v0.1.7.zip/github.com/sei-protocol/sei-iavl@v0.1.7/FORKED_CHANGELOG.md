Forked from https://github.com/cosmos/iavl/tree/v0.19.4
Last commit:
```
commit f4499a9daed0a190a4df8d55950fb5d51c835bc9 (HEAD, tag: v0.19.4)
Author: Marko <marbar3778@yahoo.com>
Date:   Fri Oct 28 00:37:21 2022 +0200

    chore: changelog for 0.19.4 (#600)
```

# Changelog


## Current - 2023-01-26

### Bug Fixes


### Improvements


### Features
