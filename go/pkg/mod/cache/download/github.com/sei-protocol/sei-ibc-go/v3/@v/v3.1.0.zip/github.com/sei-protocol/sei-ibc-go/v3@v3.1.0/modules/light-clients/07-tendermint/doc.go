/*
Package tendermint implements a concrete `ConsensusState`, `Header`,
`Misbehaviour` and `Equivocation` types for the Tendermint consensus light client.
*/
package tendermint
