/*
Package localhost implements a concrete `ConsensusState`, `Header`,
`Misbehaviour` and `Equivocation` types for the loop-back client.
*/
package localhost
