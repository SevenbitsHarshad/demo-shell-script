package types

const (
	// SubModuleName for the localhost (loopback) client
	SubModuleName = "localhost"
)
