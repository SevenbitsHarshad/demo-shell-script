# Proto Files

Use `scripts/protocgen.sh` to generate/update proto files. Ignite CLI was not meant to be used for cosmos-sdk/sei-cosmos.