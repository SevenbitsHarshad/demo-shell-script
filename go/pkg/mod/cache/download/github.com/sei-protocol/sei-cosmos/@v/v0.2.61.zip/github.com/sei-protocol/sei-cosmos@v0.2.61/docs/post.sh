#!/usr/bin/env bash

rm -rf modules
rm -rf run-node/cosmovisor.md
