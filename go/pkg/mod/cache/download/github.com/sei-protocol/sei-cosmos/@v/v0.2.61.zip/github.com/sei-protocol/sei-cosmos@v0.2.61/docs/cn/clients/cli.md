# CLI

> TODO: Rewrite this section to explain how CLI works for a generic SDK app.
