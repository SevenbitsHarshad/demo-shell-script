Forked from https://github.com/CosmWasm/wasmd/tree/v0.27.0
Last commit:
```
commit d63bea442bedf5b3055f3821472c7e6cafc3d813 (HEAD, tag: v0.27.0)
```

# Changelog
- Added mutex around mutable Wasm VM calls

## Current - 2023-02-06

### Bug Fixes


### Improvements


### Features