File with specific atime and mtime.

These two properties should be preserved if we provide the PreserveTimes options to copy.Copy.

The properties should be preserverd also for the directories and the links.
