# repo

This `repo` directory is an imitation of a repository controlled by git.
In most cases when we copy repositories, we DON'T want to copy `.git`.
