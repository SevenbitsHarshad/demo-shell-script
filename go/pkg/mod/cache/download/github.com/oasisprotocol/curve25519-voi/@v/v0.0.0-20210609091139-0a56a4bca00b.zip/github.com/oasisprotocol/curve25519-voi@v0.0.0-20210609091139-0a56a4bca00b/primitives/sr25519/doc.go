// Package sr25519 implements the sr25519 signature algorithm.  See
// https://github.com/w3f/schnorrkel/.
package sr25519
