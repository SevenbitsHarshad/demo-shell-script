# Security Policy

This repository is maintained by Confio as part of the CosmWasm stack. Please
see https://github.com/CosmWasm/advisories/blob/main/SECURITY.md for our
security policy.
